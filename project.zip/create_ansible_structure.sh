#!/bin/bash

# Define base directory
BASE_DIR="ansible"

# Create directory structure
mkdir -p $BASE_DIR/{roles/app/tasks,roles/app/templates,group_vars}

# Create files with optional initial content
touch $BASE_DIR/inventory.ini
touch $BASE_DIR/deploy.yml
touch $BASE_DIR/roles/app/tasks/main.yml
touch $BASE_DIR/roles/app/templates/your-configs.j2
touch $BASE_DIR/group_vars/all.yml

echo "Ansible project structure created successfully:"
tree $BASE_DIR

